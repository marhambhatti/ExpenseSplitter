package com.expensesplitter.ui;

import com.expensesplitter.util.Session;
import com.expensesplitter.dao.ExpenseDAO;
import com.expensesplitter.dao.GroupDAO;
import com.expensesplitter.dao.SettlementDAO;
import com.expensesplitter.dao.UserDAO;
import com.expensesplitter.models.Expense;
import com.expensesplitter.models.Group;
import com.expensesplitter.models.Settlement;
import com.expensesplitter.models.User;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SettlementFrame extends JPanel {

    private JPanel settlementsPanel;
    private final GroupDAO      groupDAO      = new GroupDAO();
    private final ExpenseDAO    expenseDAO    = new ExpenseDAO();
    private final SettlementDAO settlementDAO = new SettlementDAO();

    public SettlementFrame() {
        setLayout(new BorderLayout());
        setOpaque(false);
        add(createMainContent(), BorderLayout.CENTER);
        refreshSettlements();
    }

    // ---------------------------------------------------------------
    // UI Construction
    // ---------------------------------------------------------------

    private JPanel createMainContent() {
        JPanel main = new JPanel(new BorderLayout());
        main.setOpaque(false);
        main.setBorder(new EmptyBorder(28, 30, 28, 30));

        JLabel title = new JLabel("Settlements");
        title.setFont(new Font("Segoe UI", Font.BOLD, 24));

        JLabel subtitle = new JLabel("Resolve outstanding balances across all your groups.");
        subtitle.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        subtitle.setForeground(UiStyles.TEXT_MUTED);

        JPanel titleArea = new JPanel();
        titleArea.setLayout(new BoxLayout(titleArea, BoxLayout.Y_AXIS));
        titleArea.setOpaque(false);
        titleArea.add(title);
        titleArea.add(Box.createVerticalStrut(4));
        titleArea.add(subtitle);

        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);
        header.setBorder(new EmptyBorder(0, 0, 20, 0));
        header.add(titleArea, BorderLayout.WEST);

        settlementsPanel = new JPanel();
        settlementsPanel.setLayout(new BoxLayout(settlementsPanel, BoxLayout.Y_AXIS));
        settlementsPanel.setOpaque(false);

        JScrollPane scroll = new JScrollPane(settlementsPanel);
        scroll.setBorder(null);
        scroll.getViewport().setBackground(UiStyles.TABLE_HEADER_BG);
        scroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

        main.add(header, BorderLayout.NORTH);
        main.add(scroll, BorderLayout.CENTER);
        return main;
    }

    // ---------------------------------------------------------------
    // Refresh / populate
    // ---------------------------------------------------------------

    public void refreshSettlements() {
        settlementsPanel.removeAll();

        User user = Session.getCurrentUser();
        if (user == null) {
            settlementsPanel.add(createEmptyLabel("Please log in to view settlements."));
            finishRefresh();
            return;
        }

        List<Group> userGroups = groupDAO.getGroupsByUser(user.getId());
        if (userGroups.isEmpty()) {
            settlementsPanel.add(createEmptyLabel("No groups found. Create a group to get started."));
            finishRefresh();
            return;
        }

        boolean hasSettlements = false;
        for (Group group : userGroups) {
            JPanel groupPanel = createGroupSettlementPanel(group, user.getId());
            if (groupPanel != null) {
                hasSettlements = true;
                settlementsPanel.add(groupPanel);
                settlementsPanel.add(Box.createVerticalStrut(16));
            }
        }

        if (!hasSettlements) {
            settlementsPanel.add(createEmptyLabel("All expenses are settled! 🎉"));
        }

        finishRefresh();
    }

    private void finishRefresh() {
        settlementsPanel.revalidate();
        settlementsPanel.repaint();
    }

    // ---------------------------------------------------------------
    // Per-group panel
    // ---------------------------------------------------------------

    private JPanel createGroupSettlementPanel(Group group, int userId) {
        // net balance of userId with every other member in this group
        Map<Integer, Double> balances = calculateNetBalances(group.getId(), userId);

        if (balances.isEmpty()) return null;

        List<User> members = groupDAO.getGroupMembers(group.getId());

        // Build only the cards that are still non-zero
        List<JPanel> cards = new ArrayList<>();
        for (User member : members) {
            if (member.getId() == userId) continue;
            Double balance = balances.get(member.getId());
            if (balance != null && Math.abs(balance) > 0.01) {
                cards.add(createSettlementCard(member, balance, userId, group.getId()));
            }
        }

        if (cards.isEmpty()) return null;

        JPanel groupPanel = new JPanel();
        groupPanel.setLayout(new BoxLayout(groupPanel, BoxLayout.Y_AXIS));
        groupPanel.setOpaque(false);

        JLabel groupTitle = new JLabel("📁 " + group.getName());
        groupTitle.setFont(new Font("Segoe UI", Font.BOLD, 14));
        groupTitle.setAlignmentX(Component.LEFT_ALIGNMENT);
        groupPanel.add(groupTitle);
        groupPanel.add(Box.createVerticalStrut(8));

        for (JPanel card : cards) {
            groupPanel.add(card);
            groupPanel.add(Box.createVerticalStrut(8));
        }

        return groupPanel;
    }

    // ---------------------------------------------------------------
    // Balance calculation  ← THE KEY FIX
    // ---------------------------------------------------------------

    /**
     * Returns a map: memberId → net amount owed TO the current user (userId).
     *
     * Positive  → that member owes the current user money.
     * Negative  → the current user owes that member money.
     *
     * Past settlements are subtracted so already-resolved balances
     * disappear from the list.
     */
    private Map<Integer, Double> calculateNetBalances(int groupId, int userId) {

        List<User>    members     = groupDAO.getGroupMembers(groupId);
        List<Expense> expenses    = expenseDAO.getExpensesByGroup(groupId);
        List<Settlement> settled  = settlementDAO.getSettlementsByGroup(groupId);

        // Initialize every member to 0.0
        Map<Integer, Double> balances = new HashMap<>();
        for (User m : members) {
            balances.put(m.getId(), 0.0);
        }

        int memberCount = members.size();
        if (memberCount == 0) return balances;

        // --- Step 1: accumulate from expenses ---
        for (Expense expense : expenses) {
            double share = expense.getAmount() / memberCount;
            int paidBy   = expense.getPaidBy();

            if (paidBy == userId) {
                // Every other member owes userId their share
                for (User m : members) {
                    if (m.getId() != userId) {
                        balances.merge(m.getId(), share, Double::sum);
                    }
                }
            } else {
                // userId owes paidBy one share (negative = userId owes)
                balances.merge(paidBy, -share, Double::sum);
            }
        }

        // --- Step 2: subtract past settlements ---
        for (Settlement s : settled) {
            int payer = s.getPayerId();
            int payee = s.getPayeeId();
            double amt = s.getAmount();

            if (payee == userId) {
                // Someone paid userId → reduces what they owe us
                balances.merge(payer, -amt, Double::sum);
            } else if (payer == userId) {
                // userId paid someone → reduces what we owe them
                balances.merge(payee, amt, Double::sum);
            }
            // settlements between two other members don't affect userId's view
        }

        // --- Step 3: drop near-zero entries ---
        balances.entrySet().removeIf(e -> Math.abs(e.getValue()) <= 0.01);

        return balances;
    }

    // ---------------------------------------------------------------
    // Settlement card
    // ---------------------------------------------------------------

    private JPanel createSettlementCard(User otherUser, double balance,
                                        int userId, int groupId) {
        // balance > 0  → otherUser owes current user
        // balance < 0  → current user owes otherUser
        boolean userOwes  = balance < 0;
        double  absAmount = Math.abs(balance);

        JPanel card = new JPanel(new BorderLayout(12, 0));
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UiStyles.CARD_BORDER),
                new EmptyBorder(12, 14, 12, 14)));
        card.setMaximumSize(new Dimension(Integer.MAX_VALUE, 60));

        // Avatar circle
        JPanel avatar = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                        RenderingHints.VALUE_ANTIALIAS_ON);
                Color bg = userOwes ? new Color(254, 226, 226) : new Color(219, 234, 254);
                g2.setColor(bg);
                g2.fillOval(0, 0, getWidth(), getHeight());
                g2.setColor(userOwes ? new Color(185, 28, 28) : new Color(29, 78, 216));
                g2.setFont(new Font("Segoe UI", Font.BOLD, 12));
                FontMetrics fm = g2.getFontMetrics();
                String initial = String.valueOf(otherUser.getName().charAt(0)).toUpperCase();
                g2.drawString(initial,
                        (getWidth()  - fm.stringWidth(initial)) / 2,
                        (getHeight() + fm.getAscent() - fm.getDescent()) / 2);
                g2.dispose();
            }
        };
        avatar.setPreferredSize(new Dimension(36, 36));
        avatar.setOpaque(false);

        // Text
        JLabel nameLabel = new JLabel(otherUser.getName());
        nameLabel.setFont(new Font("Segoe UI", Font.BOLD, 13));

        String statusText = userOwes
                ? "You owe Rs. " + String.format("%.2f", absAmount)
                : "Owes you Rs. " + String.format("%.2f", absAmount);

        JLabel statusLabel = new JLabel(statusText);
        statusLabel.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        statusLabel.setForeground(userOwes ? new Color(185, 28, 28) : new Color(29, 78, 216));

        JPanel textPanel = new JPanel();
        textPanel.setLayout(new BoxLayout(textPanel, BoxLayout.Y_AXIS));
        textPanel.setOpaque(false);
        textPanel.add(nameLabel);
        textPanel.add(statusLabel);

        card.add(avatar,    BorderLayout.WEST);
        card.add(textPanel, BorderLayout.CENTER);

        // "Settle" button only when the other person owes the current user
        if (!userOwes) {
            JButton settleBtn = new JButton("Settle");
            settleBtn.setFont(new Font("Segoe UI", Font.PLAIN, 11));
            settleBtn.setBackground(new Color(29, 78, 216));
            settleBtn.setForeground(Color.WHITE);
            settleBtn.setBorderPainted(false);
            settleBtn.setFocusPainted(false);
            settleBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            settleBtn.addActionListener(e ->
                    recordSettlement(userId, otherUser.getId(), groupId, absAmount));
            card.add(settleBtn, BorderLayout.EAST);
        }

        return card;
    }

    // ---------------------------------------------------------------
    // Record settlement
    // ---------------------------------------------------------------

    private void recordSettlement(int payerId, int payeeId, int groupId, double amount) {
        Date today = new Date(System.currentTimeMillis());
        Settlement settlement = new Settlement(groupId, payerId, payeeId, amount, today);

        String error = settlementDAO.addSettlementWithMessage(settlement);
        if (error == null) {
            JOptionPane.showMessageDialog(this,
                    "Settlement recorded successfully!", "Success",
                    JOptionPane.INFORMATION_MESSAGE);
            refreshSettlements();          // live update — settled entry disappears
        } else {
            JOptionPane.showMessageDialog(this,
                    "Failed to record settlement.\n" + error, "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    // ---------------------------------------------------------------
    // Helpers
    // ---------------------------------------------------------------

    private JLabel createEmptyLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        label.setForeground(new Color(120, 130, 145));
        label.setAlignmentX(Component.LEFT_ALIGNMENT);
        label.setBorder(new EmptyBorder(40, 0, 40, 0));
        return label;
    }
}